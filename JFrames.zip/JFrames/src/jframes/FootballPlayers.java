/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframes;

/**
 *
 * @author Zach
 */
class FootballPlayers {
    private final String first_Name;
    private final String last_Name;
    private final int age;
    private final String position;

    public FootballPlayers(String first_Name, String last_Name, int age, String position) {
        this.first_Name = first_Name;
        this.last_Name = last_Name;
        this.age = age;
        this.position = position;
    }
        
     String getInfo(){
         double r = Math.random();
         int rushingyards = (int) (r * 100);
         
         return(first_Name+  " " +last_Name + " " + age + " " + position + ". " + "The number of rushing yards for this player is " +rushingyards);
         
                
    }
    
}