/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframes;


import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author Zach
 */
class MyJPanel extends JPanel {
    public MyJPanel(){
    setBackground(Color.pink);
    ArrayList<FootballPlayers> FootballPlayers = new ArrayList();
    FootballPlayers.add(new FootballPlayers("Andy", "Hyun" , 23 ,"Fullback"));
    FootballPlayers.add(new FootballPlayers("Jerry", "White" , 38 ,"Middle"));
    FootballPlayers.add(new FootballPlayers("Tex", "Fauster" , 28 ,"Quarterback"));
    FootballPlayers.add(new FootballPlayers("Henry", "Jackson" , 22 ,"Wide Reciever"));
    FootballPlayers.add(new FootballPlayers("Aaron", "Steele" , 19 ,"Wide Reciever"));
    FootballPlayers.add(new FootballPlayers("Logan", "Poplino" , 34 ,"Offensive Tackle"));
    FootballPlayers.add(new FootballPlayers("Chris", "Filan" , 27 ,"Offensive Line"));
    FootballPlayers.add(new FootballPlayers("Luke", "Manlin" , 24 ,"Halfback"));
    FootballPlayers.add(new FootballPlayers("Mark", "Zipperman" , 34 ,"Quarterback"));
    FootballPlayers.add(new FootballPlayers("Lucious", "Lyon" , 26 ,"Offensive Line"));
    FootballPlayers.add(new FootballPlayers("Henry", "Parker" , 28 ,"Offensive Line"));
      
        
    
    FootballPlayers.forEach((pla) -> {
        add(new JButton(pla.getInfo()));
        });
    
    
    

}
    
}
