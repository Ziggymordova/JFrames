/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jframes;

import javax.swing.JFrame;


/**
 *
 * @author Zach
 */
class MyJFrame extends JFrame{
    public MyJFrame(){
        super("The Football players on the team");
        setVisible(true);
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        MyJPanel jp1 = new MyJPanel();
        add(jp1);
    }
}
